﻿# 解压目录 /tmp/

# windows打开过的脚本要改文件格式为unix
vi install.sh
set ff=unix
wq

# nginx
location /guacamole/ {
    client_max_body_size    100m;
    proxy_pass http://127.0.0.1:8080/guacamole/;
    proxy_buffering off;
    proxy_http_version 1.1;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection $http_connection;
    access_log off;
}

django配置:
安装配置java环境
yum install -y java-1.8.0-openjdk-devel.x86_64

cat <<"EOF" >> /etc/profile
export JAVA_HOME=/usr/lib/jvm/java
export JRE_HOME=${JAVA_HOME}/jre 
export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib 
export PATH=${JAVA_HOME}/bin:$PATH
EOF
source /etc/profile

安装调用python库，依赖python-devel
pip install cython
pip install pyjnius