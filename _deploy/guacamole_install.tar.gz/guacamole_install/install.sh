# 扩展源
yum install -y epel-release
rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-7
rpm --import http://li.nux.ro/download/nux/RPM-GPG-KEY-nux.ro 
rpm -Uvh http://li.nux.ro/download/nux/dextop/el7/x86_64/nux-dextop-release-0-1.el7.nux.noarch.rpm
yum update -y

yum install -y gcc gcc-c++ make nasm wget unzip
yum install -y libtool git tomcat mariadb mariadb-devel mariadb-server
# 解决tomcat启动慢
yum install -y rng-tools
cp /usr/lib/systemd/system/rngd.service /etc/systemd/system
sed -i 's/ExecStart=\/sbin\/rngd -f/ExecStart=\/sbin\/rngd -f -r \/dev\/urandom/g' /etc/systemd/system/rngd.service
systemctl daemon-reload
systemctl restart rngd

yum install -y cairo-devel libjpeg-turbo-devel libjpeg-devel libpng-devel uuid-devel
yum install -y pango-devel libssh2-devel libvncserver-devel libvorbis-devel libwebp-devel pulseaudio-libs-devel openssl-devel
yum install -y libtelnet-devel ffmpeg-devel

# # freerdp manually
yum install -y gcc cmake openssl-devel libX11-devel libXext-devel libXinerama-devel libXcursor-devel libXi-devel libXdamage-devel libXv-devel libxkbfile-devel alsa-lib-devel cups-devel ffmpeg-devel glib2-devel
cd /tmp/guacamole_install/
unzip FreeRDP-stable-1.1.zip
cd FreeRDP-stable-1.1
cmake -DCMAKE_BUILD_TYPE=Debug -DWITH_SSE2=ON .
make
make install
touch /etc/ld.so.conf.d/freerdp.conf
cat <<"EOF" > /etc/ld.so.conf.d/freerdp.conf
/usr/local/lib/freerdp
/usr/local/lib
/usr/local/lib64
EOF
ldconfig
# # uninstall freerdp
# # xargs rm < install_manifest.txt

# install font yahei_mono
yum install -y fontconfig mkfontscale
cd /tmp/guacamole_install/
mkdir /usr/share/fonts/yahei_mono/
cp yahei_mono.ttf /usr/share/fonts/yahei_mono/
cd /usr/share/fonts/yahei_mono/
mkfontscale
mkfontdir
fc-cache -fv
source /etc/profile


# guacamole-server
cd /tmp/guacamole_install/
tar -zxvf guacamole-server-0.9.12-incubating.tar.gz
cd guacamole-server-0.9.12-incubating
# 修改rdp挂载盘名称为文件传输盘
sed -i 's/int name_bytes/\/\/ &/' src/protocols/rdp/guac_rdpdr/rdpdr_messages.c
sed -i 's/const char\* name/&, int name_bytes/' src/protocols/rdp/guac_rdpdr/rdpdr_messages.c
sed -i '65d' src/protocols/rdp/guac_rdpdr/rdpdr_messages.c
sed -i '64 a\    Stream_Write_UINT32(output_stream, 1); \/\* ASCII \*\/' src/protocols/rdp/guac_rdpdr/rdpdr_messages.c
sed -i '164d' src/protocols/rdp/guac_rdpdr/rdpdr_messages.c
sed -i '163 a\    char name[] = "\\x87\\x65\\xf6\\x4e\\x20\\x4f\\x93\\x8f\\xd8\\x76\\0";' src/protocols/rdp/guac_rdpdr/rdpdr_messages.c
sed -i '164 a\    guac_rdpdr_send_client_name_request(rdpdr, name, sizeof(name));' src/protocols/rdp/guac_rdpdr/rdpdr_messages.c
sed -i 's/\"GUAC/\"G\\0\\0\\0/' src/protocols/rdp/guac_rdpdr/rdpdr_fs_service.c
# autoreconf -fi
./configure
make
make install
mkdir /usr/local/lib64/freerdp
ln -s /usr/local/lib/freerdp/guac*.so /usr/local/lib64/freerdp
ldconfig
mkdir -p ~/.config/freerdp/
guacd


# guacamole-client
cd /tmp/guacamole_install/
cp guacamole-0.9.12-incubating-modified.war /var/lib/tomcat/webapps/guacamole.war

# ------ mysql auth config ------
# guacamole-client jdbc extension
mkdir -p /usr/share/tomcat/.guacamole/extensions/
tar -zxvf guacamole-auth-jdbc-0.9.12-incubating-modified.tar.gz
cp guacamole-auth-jdbc-0.9.12-incubating/mysql/guacamole-auth-jdbc-mysql-0.9.12-incubating.jar /usr/share/tomcat/.guacamole/extensions/

# guacamole-client mysql lib
mkdir -p /usr/share/tomcat/.guacamole/lib/
tar -zxvf mysql-connector-java-5.1.42.tar.gz
cp mysql-connector-java-5.1.42/mysql-connector-java-5.1.42-bin.jar /usr/share/tomcat/.guacamole/lib/

# guacamole-client mysql database config
systemctl start mariadb
mysql -e "
CREATE DATABASE guacamole_db;
CREATE USER 'guacamole_user'@'localhost' IDENTIFIED BY 'guacamole_pass';
CREATE USER 'guacamole_user'@'%' IDENTIFIED BY 'guacamole_pass';
GRANT SELECT,INSERT,UPDATE,DELETE ON guacamole_db.* TO 'guacamole_user'@'localhost';
GRANT SELECT,INSERT,UPDATE,DELETE ON guacamole_db.* TO 'guacamole_user'@'%';
FLUSH PRIVILEGES;
quit
"
cat guacamole-auth-jdbc-0.9.12-incubating/mysql/schema/*.sql | mysql guacamole_db

# guacamole-client mysql connection config
touch /usr/share/tomcat/.guacamole/guacamole.properties
cat <<"EOF" > /usr/share/tomcat/.guacamole/guacamole.properties
mysql-hostname: localhost
mysql-port: 3306
mysql-database: guacamole_db
mysql-username: guacamole_user
mysql-password: guacamole_pass

api-session-timeout: 1440
EOF
# ------ mysql auth config ------

# ------ xml auth config ------
# mkdir /usr/share/tomcat/.guacamole/
# mkdir /etc/guacamole/
# touch /etc/guacamole/guacamole.properties
# cat <<"EOF" > /etc/guacamole/guacamole.properties
# basic-user-mapping: /etc/guacamole/user-mapping.xml
# EOF
# touch /etc/guacamole/user-mapping.xml
# cat <<"EOF" > /etc/guacamole/user-mapping.xml
# <user-mapping>
#     <authorize username="admin" password="admin">
#         <connection name="ssh">
#             <protocol>ssh</protocol>
#             <param name="hostname">localhost</param>
#             <param name="port">22</param>
#             <param name="username">root</param>
#             <param name="password">123</param>
#             <param name="color-scheme">white-black</param>
#             <param name="font-name">Courier 10 Pitch</param>
#         </connection>
#     </authorize>
# </user-mapping>
# EOF
# ln -s /etc/guacamole/guacamole.properties /usr/share/tomcat/.guacamole/
# ------ xml auth config ------

setenforce 0
tomcat start
